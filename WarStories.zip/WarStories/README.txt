WAR STORIES · CHAIN OF COMMAND

1. Unzip this folder anywhere.
2. Double-click index.html. It opens in your web browser (Chrome, Edge, Firefox or Safari).
3. Pick your AI provider, paste your own API key, click "Report for duty".

For phones: host the folder (Netlify Drop, Cloudflare Pages or GitHub Pages) and open the link; see the README on GitHub.
Everything in the game is fiction.
